# Burundi Hub Full-Stack App

## Setup Instructions

### Backend:
```bash
cd backend
npm install
npm run dev
```

### Frontend:
```bash
cd frontend
npm install
npm start
```