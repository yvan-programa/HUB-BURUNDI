exports.register = (req, res) => {
  res.send('User registered');
};